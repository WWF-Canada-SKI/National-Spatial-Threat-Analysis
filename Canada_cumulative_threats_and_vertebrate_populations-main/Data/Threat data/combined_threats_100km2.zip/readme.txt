This dataset contains cumulative threat data from the article: Under pressure: the relationship between vertebrate populations and high-intensity cumulative threats in habitats across Canada (Currie et al., 2025).

Contact info:
Chris Liang
WWF-Canada
Specialist, GIS & Spatial Analysis
cliang@wwfcanada.org

Dataset: combined_threat_map_canada_100km2_20250327.shp

Columns:
index - unique ID of each 100km2 hexbin
sum_high - number of high-intensity threats (> 90th percentile)
sm_qntl - the percentile of threat values in each hexbin, summed across threats
hmn_pp_v - human population threat value
hmn_pp_q - human population threat quantile
threat_pre - total number of threats present
avg_qntl - average percentile of threats in each hexbin

The column sum_high is visualized on a map (Figure 2).

